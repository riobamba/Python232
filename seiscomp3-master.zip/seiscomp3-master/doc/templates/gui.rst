#########################
Graphical user interfaces
#########################

.. toctree::
   :maxdepth: 2

${generator.refs.gui}
