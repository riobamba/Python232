The tab2inv program is part of the nettab package distributed together with the SeisComp3 package. The nettab is a text based format developed inside the GEOFON data center to describe seismological instruments responses information. The tab2inv program can generate SeisComp3 inventory files from the parsing of the tab files as described by in the nettab format.

This program can read a set of tab files in the nettab format, verify their contents and generate the inventory for the stations described in them.
