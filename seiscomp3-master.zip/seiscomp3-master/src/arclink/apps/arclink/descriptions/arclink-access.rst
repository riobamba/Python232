The Arclink access module is a virtual module that does not contain a binary.
It is used to define access rule for particular stations and thus only provides
bindings. The module itself does not need any configuration.
