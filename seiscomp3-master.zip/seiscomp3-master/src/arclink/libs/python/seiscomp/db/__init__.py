
class DBError(Exception):
    pass

