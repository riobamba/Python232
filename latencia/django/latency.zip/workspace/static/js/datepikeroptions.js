$('#datetimepicker_mask').datetimepicker({
	//mask : '9999-19-39 29:59:00',
	format : 'Y-m-d H:i:i'
});

$('#datetimepicker_mask1').datetimepicker({
	//mask : '9999-19-39 29:59:00',
	format : 'Y-m-d H:i:i'
});

