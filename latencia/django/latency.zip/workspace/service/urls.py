from django.conf.urls import url
from service import views
from service.views import index

urlpatterns = [
    url(r'^$', index, name='index'),
    url(r'^latencia/$', views.service_list),
]